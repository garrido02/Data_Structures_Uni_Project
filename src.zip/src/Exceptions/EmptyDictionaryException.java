package Exceptions;

public class EmptyDictionaryException extends Exception{
}
