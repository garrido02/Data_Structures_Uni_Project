package dataStructures;
import Exceptions.*;

public class OpenHashTableIterator<K extends Comparable<K>,V> implements Iterator<Entry<K,V>> {
    private static final long serialVersionUID = 0L;

    private int size;
    private int current;
    protected Dictionary<K, V>[] table;
    private Iterator<Entry<K, V>> iterator;
    private int returned; // quantity of elements returned

    public OpenHashTableIterator(SepChainHashTable<K, V> hashTable, int size) throws EmptyTreeException, FullStackException {
        table = hashTable.table;
        this.size = size;
        current = 0;
        returned = 0;
        findNext();
    }

    @Override
    public boolean hasNext() {
        return returned < size && current < table.length;
    }

    @Override
    public Entry<K, V> next() throws NoSuchElementException, EmptyTreeException, EmptyStackException, EmptyQueueException, FullStackException, FullQueueException {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        if (iterator != null && iterator.hasNext()) {
            returned++;
            return iterator.next();
        }
        findNext();
        if (iterator != null && iterator.hasNext()) {
            returned++;
            return iterator.next();
        }
        throw new NoSuchElementException();
    }

    private void findNext() throws EmptyTreeException, FullStackException {
        // Enquanto ainda houver buckets para examinar
        while (current < table.length) {
            // Se o iterador é nulo ou não tem mais elementos, tenta inicializar
            if (iterator == null || !iterator.hasNext()) {
                if (table[current] == null || table[current].isEmpty()) {
                    current++; // Avança para o próximo bucket
                } else {
                    // Inicializa o iterador para o bucket atual
                    iterator = table[current].iterator();
                    if (iterator.hasNext()) {
                        return; // Encontrou um elemento válido
                    } else {
                        current++; // Se o bucket está vazio, avança
                    }
                }
            } else {
                return; // Iterador atual ainda é válido
            }
        }
        iterator = null; // Não há mais elementos
    }



    @Override
    public void rewind() throws EmptyTreeException, FullStackException {
        current = 0;
        returned = 0;
        findNext(); // Reset the iterator
    }
}
