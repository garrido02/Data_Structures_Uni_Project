/**
 * Class Line
 * @Authors Francisco Correia 67264 & Sérgio Garrido 67202
 */

package RedeFerroviaria;
import Exceptions.*;
import dataStructures.*;
import Enums.Constants;

/**
 * Class Line responsible to implements the methods prototyped in the LineUpdatable interface
 */
public class LineClass implements LineUpdatable {
    /**
     * Constant variables
     */
    private static final int ZERO = Constants.ZERO.getValue();
    private static final int ONE = Constants.ONE.getValue();

    /**
     * Instance Variables
     */
    private String name;
    // Tree departure time of terminal 1 && 2
    private OrderedDictionary<Date, Train> departureTerminal1;
    private OrderedDictionary<Date, Train> departureTerminal2;
    // Stations by order of insertion
    private List<Station> stationsByInsertion;
    // Map of stations K - Name of station; V - Station
    private Dictionary<String, Station> stations;

    static final long serialVersionUID = 0L;

    /**
     * Constructor
     *
     * @param name - The name of the line
     */
    public LineClass(String name) {
        this.stations = new SepChainHashTable<>(Constants.DEFAULT_STATIONS.getValue());
        this.stationsByInsertion = new DoubleList<>();
        this.departureTerminal1 = new AVLTree<>();
        this.departureTerminal2 = new AVLTree<>();
        this.name = name;
    }

    @Override
    public void addStation(Station station) {
        StationUpdatable s = (StationUpdatable) station;
        s.insertLine(this.name);
        stations.insert(station.getName().toLowerCase(), s);
        stationsByInsertion.addLast(s);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void addSchedule(int trainNr, List<Entry<String, String>> stationsToAdd) {
        Iterator<Entry<String, String>> ite = stationsToAdd.iterator();


        String startingStation = stationsToAdd.getFirst().getKey().toLowerCase();
        String hour = stationsToAdd.getFirst().getValue();

        Date departureTime = new DateClass(hour);
        Station station = stations.find(startingStation);

        // Handle Train
        TrainUpdatable t = new TrainClass(trainNr);
        t.setDepartureStation(station);
        t.setDepartureTime(departureTime);

        // Handle insertions
        if (station.getName().equalsIgnoreCase(stationsByInsertion.getFirst().getName())) {
            departureTerminal1.insert(departureTime, t);
        } else {
            departureTerminal2.insert(departureTime, t);
        }

        List<Entry<String, Date>> trainSchedule = new DoubleList<>();
        // Handle stations schedule insertions
        while (ite.hasNext()) {
            Entry<String, String> nextEntry = ite.next();
            String stationName = nextEntry.getKey();
            Date time = new DateClass(nextEntry.getValue());
            trainSchedule.addLast(new EntryClass(stationName, time));

            StationUpdatable s = (StationUpdatable) stations.find(stationName.toLowerCase());
            ;
            s.addSchedule(t, time);
        }
        t.setSchedule(trainSchedule);
    }

    @Override
    public boolean hasSchedule(String stationName, String hour) {
        Date time = new DateClass(hour);

        if (!isTerminalStation(stationName)) {
            return false;
        }

        OrderedDictionary<Date, Train> departureOrientation;

        if (stationName.equalsIgnoreCase(stationsByInsertion.getFirst().getName())) {
            departureOrientation = departureTerminal1;
        } else {
            departureOrientation = departureTerminal2;
        }
        try {
            Iterator<Entry<Date, Train>> iterator = departureOrientation.iterator();
            boolean found = false;
            while (iterator.hasNext() && !found) {
                Entry<Date, Train> entry = iterator.next();
                Date d = entry.getKey();
                if (d.compareTo(time) == 0) {
                    found = true;
                }
            }
            return found;
        } catch (EmptyTreeException e) {
            return false;
        }
    }

    @Override
    public boolean hasStation(String station) {
        return stations.find(station) != null;
    }

    @Override
    public void removeSchedule(String startingStation, String hour) {
        try {
            Date time = new DateClass(hour);
            Train t;

            if (startingStation.equalsIgnoreCase(stationsByInsertion.getFirst().getName())) {
                t = departureTerminal1.find(time);
                departureTerminal1.remove(time);
            } else {
                t = departureTerminal2.find(time);
                departureTerminal2.remove(time);
            }

            Iterator<Entry<String, Date>> scheduleIte = t.scheduleIterator();
            while (scheduleIte.hasNext()) {
                Entry<String, Date> entry = scheduleIte.next();
                StationUpdatable station = (StationUpdatable) stations.find(entry.getKey().toLowerCase());
                station.removeSchedule(entry.getValue(), t);
            }
        } catch (EmptyDictionaryException ignore){}
    }

    @Override
    public List<Station> removeLineFromStations() {
        Iterator<Station> ite = stationsByInsertion.iterator();
        List<Station> stationsToRemove = new DoubleList<>();
        while (ite.hasNext()) {
            StationUpdatable s = (StationUpdatable) ite.next();
            s.removeLine(this.name);
            if (s.isObsolete()){
                stationsToRemove.addLast(s);
            }
        }
        return stationsToRemove;
    }

    @Override
    public boolean isTerminalStation(String station) {
        return stationsByInsertion.getFirst().getName().equalsIgnoreCase(station) || stationsByInsertion.getLast().getName().equalsIgnoreCase(station);
    }


    @Override
    public boolean orderCorrect(List<Entry<String, String>> stations) {
        return stationsInOrder(stations) && hourInOrder(stations);
    }

    /**
     * Checks if a given route follows the line's order of stations
     *
     * @param stations - The list of stations to be added
     * @return true if the list of stations follows the line's order of stations. Otherwise, false
     */
    private boolean stationsInOrder(List<Entry<String, String>> stations) {
        String station = stations.getFirst().getKey();
        int i = ZERO;
        if (!station.equalsIgnoreCase(this.stationsByInsertion.getFirst().getName())) {
            i = stationsByInsertion.size() - ONE;
        }
        int j = ZERO;
        if (i == ZERO) {
            while (i < stationsByInsertion.size() && j < stations.size()) {
                Station s = stationsByInsertion.get(i);
                if (s.getName().equalsIgnoreCase(stations.get(j).getKey())) {
                    i++;
                    j++;
                } else {
                    i++;
                }
            }
        } else {
            while (i >= ZERO && j < stations.size()) {
                Station s = stationsByInsertion.get(i);
                if (s.getName().equalsIgnoreCase(stations.get(j).getKey())) {
                    i--;
                    j++;
                } else {
                    i--;
                }
            }
        }
        return j == stations.size();
    }


    /**
     * Checks if a given route has the hour of departure in each station in crescent order
     *
     * @param stations - The list of stations
     * @return true if the list of stations have their departure hour in crescent order. Otherwise, false
     */
    private boolean hourInOrder(List<Entry<String, String>> stations) {
        Station starter = this.stations.find(stations.getFirst().getKey().toLowerCase());
        Date starterDate = new DateClass(stations.getFirst().getValue());

        Iterator<Entry<String, String>> ite = stations.iterator();
        boolean result = true;
        Date prev = null;
        while (ite.hasNext() && result) {
            Entry<String, String> entry = ite.next();
            Date currentDate = new DateClass(entry.getValue());
            Station currentStation = this.stations.find(entry.getKey().toLowerCase());
            if (prev != null) {
                int hour = currentDate.getHour() - prev.getHour();
                if (hour == ZERO) {
                    int minute = currentDate.getMinutes() - prev.getMinutes();
                    result = minute >= ONE;
                } else {
                    result = hour >= ONE;
                }
            }
            if (hasOvercome(starter, starterDate, currentStation, currentDate)) {
                result = false;
            }
            prev = currentDate;
        }
        return result;
    }

    private boolean hasOvercome(Station starter, Date starterDate, Station currentStation, Date currentdDate){
        OrderedDictionary<Date, Train> direction;

        if (starter.getName().equalsIgnoreCase(stationsByInsertion.getFirst().getName())) {
            direction = departureTerminal1;
        } else {
            direction = departureTerminal2;
        }

        if (direction.isEmpty()) {
            return false;
        }

        try {
            Iterator<Entry<Date, Train>> ite = direction.iterator();
            boolean result = false;
            while (ite.hasNext() && !result) {
                Entry<Date, Train> entry = ite.next();
                Date d = entry.getKey();
                Train t = entry.getValue();
                Iterator<Entry<Date, OrderedDictionary<Integer, Train>>> ite2 = currentStation.trainsIterator();
                if (Date.calculateDiff(starterDate, d) == 0){
                    return true;
                }
                if (starterDate != d && Date.calculateDiff(starterDate, d) < 0) {
                    while (ite2.hasNext() && !result) {
                        Entry<Date, OrderedDictionary<Integer, Train>> entry2 = ite2.next();
                        Date d2 = entry2.getKey();
                        Iterator<Entry<Integer, Train>> trainIte = entry2.getValue().iterator();
                        while (trainIte.hasNext() && !result) {
                            Entry<Integer, Train> entry3 = trainIte.next();
                            Train t2 = entry3.getValue();
                            if (t2.equals(t) && Date.calculateDiff(currentdDate, d2) >= 0) {
                                result = true;
                            }
                        }
                    }
                } else if (starterDate != d && Date.calculateDiff(starterDate, d) > 0) {
                    while (ite2.hasNext() && !result) {
                        Entry<Date, OrderedDictionary<Integer, Train>> entry2 = ite2.next();
                        Date d2 = entry2.getKey();
                        Iterator<Entry<Integer, Train>> trainIte = entry2.getValue().iterator();
                        while (trainIte.hasNext() && !result) {
                            Entry<Integer, Train> entry3 = trainIte.next();
                            Train t2 = entry3.getValue();
                            if (t2.equals(t) && Date.calculateDiff(currentdDate, d2) <= 0) {
                                result = true;
                            }
                        }
                    }
                } else {
                    result = false;
                }
            }
            return result;
        } catch (EmptyTreeException e) {
            return false;
        }
    }

    @Override
    public Iterator<Station> stationsIterator() {
        return stationsByInsertion.iterator();
    }

    @Override
    public Iterator<Entry<Date, Train>> trainsPerStationsIterator(String startingStation) throws EmptyTreeException, FullStackException {
        Iterator<Entry<Date, Train>> ite;
        if (stationsByInsertion.getFirst().getName().equalsIgnoreCase(startingStation)){
            if (departureTerminal1.isEmpty()){
                ite = null;
            } else {
                ite = departureTerminal1.iterator();
            }
        } else {
            if (departureTerminal2.isEmpty()){
                ite = null;
            } else {
                ite = departureTerminal2.iterator();
            }
        }
        return ite;
    }

    @Override
    public Train bestTimeTable(String startingStation, String endingStation, String hour) throws EmptyTreeException, EmptyStackException, EmptyQueueException, FullStackException, FullQueueException {
        Date arrivalTime = new DateClass(hour);

        Station starter = stations.find(startingStation);
        Station ender = stations.find(endingStation);
        int starterIdx = stationsByInsertion.find(starter);
        int enderIdx = stationsByInsertion.find(ender);

        OrderedDictionary<Date, Train> direction;
        if (starterIdx < enderIdx) {
            direction = departureTerminal1;
        } else {
            direction = departureTerminal2;
        }

        //Iterator<Entry<Date, OrderedDictionary<Integer, Train>>> ite = stations.find(startingStation).trainsIterator();
        Iterator<Entry<Date, Train>> ite = direction.iterator();
        Train bestSuited = null;
        int leeway = Integer.MIN_VALUE;
        while(ite.hasNext()){
            //Entry<Date, OrderedDictionary<Integer, Train>> entry = ite.next();
            Entry<Date, Train> entry = ite.next();
            Train t = entry.getValue();
            //Iterator<Entry<Integer, Train>> trainIte = entry.getValue().iterator();
            //while (trainIte.hasNext()){
                //Entry<Integer, Train> entry2 = trainIte.next();
                //Train t = entry2.getValue();
                if (starter.hasTrain(t) && ender.hasTrain(t)){
                    int r = Date.calculateDiff(ender.getTrainSchedule(t), arrivalTime);
                    if (r > leeway && r <= 0){
                        leeway = r;
                        bestSuited = t;
                    }
                }
            //}
        }
        return bestSuited;
    }

    @Override
    public int compareTo(Line o) {
        return this.name.compareTo(o.getName());
    }
}

/**
 * End of Class Line
 */
