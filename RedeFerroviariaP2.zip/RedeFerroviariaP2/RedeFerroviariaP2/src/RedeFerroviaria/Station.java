package RedeFerroviaria;

import Exceptions.*;
import dataStructures.*;
import java.io.Serializable;

public interface Station extends Serializable, Comparable<Station> {
    String getName();
    Iterator<Entry<String, Void>> linesIterator() throws StationDoesNotExistException;
    Iterator<Entry<Date, OrderedDictionary<Integer, Train>>> trainsIterator();
    boolean hasTrain(Train train) throws EmptyStackException, EmptyTreeException, EmptyQueueException, FullStackException, FullQueueException;
    Date getTrainSchedule(Train t) throws EmptyTreeException, FullStackException, EmptyStackException, EmptyQueueException, FullQueueException;
    boolean isObsolete();
}
