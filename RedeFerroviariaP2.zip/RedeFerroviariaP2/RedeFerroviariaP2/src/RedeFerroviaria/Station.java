package RedeFerroviaria;

import Exceptions.*;
import dataStructures.*;
import java.io.Serializable;

public interface Station extends Serializable, Comparable<Station> {
    String getName();
    Iterator<Entry<String, Void>> linesIterator() throws StationDoesNotExistException;
    Iterator<Entry<Date, OrderedDictionary<Integer, Train>>> trainsIterator();
    boolean hasTrain(Train train);
    Date getTrainSchedule(Train t) ;
    boolean isObsolete();
}
