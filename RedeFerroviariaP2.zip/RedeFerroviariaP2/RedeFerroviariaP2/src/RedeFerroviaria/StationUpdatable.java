package RedeFerroviaria;

import Exceptions.*;


public interface StationUpdatable extends Station {
    void insertLine(String lineName);
    void addSchedule(Train t, Date departure);
    void removeSchedule(Date hour, Train t);
    void removeLine(String name);
}
