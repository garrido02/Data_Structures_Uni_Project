package RedeFerroviaria;

import Exceptions.*;


public interface StationUpdatable extends Station {
    void insertLine(String lineName);
    void addSchedule(Train t, Date departure);
    void removeSchedule(Date hour, Train t) throws EmptyTreeException, FullStackException, EmptyStackException, EmptyQueueException, FullQueueException, EmptyDictionaryException;
    void removeLine(String name);
}
