package RedeFerroviaria;

import dataStructures.Entry;
import dataStructures.List;

public interface TrainUpdatable extends Train{
    void setSchedule(List<Entry<String, Date>> trainSchedule);
}
