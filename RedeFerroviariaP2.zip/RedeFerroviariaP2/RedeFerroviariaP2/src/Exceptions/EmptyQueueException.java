package Exceptions;

public class EmptyQueueException extends Exception {
}
