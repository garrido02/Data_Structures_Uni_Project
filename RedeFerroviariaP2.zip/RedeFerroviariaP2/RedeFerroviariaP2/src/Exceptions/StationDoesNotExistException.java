package Exceptions;

public class StationDoesNotExistException extends Exception{
    static final long serialVersionUID = 0L;
}
