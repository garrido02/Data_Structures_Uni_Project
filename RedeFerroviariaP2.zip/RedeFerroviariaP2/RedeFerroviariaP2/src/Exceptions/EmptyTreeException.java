package Exceptions;

public class EmptyTreeException extends Exception {
}
