package Exceptions;

public class FullQueueException extends Exception {
}
