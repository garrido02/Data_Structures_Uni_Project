package Exceptions;
public class EmptyListException extends RuntimeException{
    static final long serialVersionUID = 0L;
}

