package Exceptions;

public class EmptyStackException extends Exception{
}
