package Exceptions;

public class FullStackException extends Exception {
}
