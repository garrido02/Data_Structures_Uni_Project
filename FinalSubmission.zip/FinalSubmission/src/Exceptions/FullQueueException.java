package Exceptions;

public class FullQueueException extends Exception {
    static final long serialVersionUID = 0L;

}
