package Exceptions;

public class EmptyDictionaryException extends Exception{
    static final long serialVersionUID = 0L;

}
