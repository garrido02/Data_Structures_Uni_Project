package Exceptions;

public class FullStackException extends Exception {
    static final long serialVersionUID = 0L;

}
