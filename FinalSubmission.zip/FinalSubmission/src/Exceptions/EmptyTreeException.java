package Exceptions;

public class EmptyTreeException extends Exception {
    static final long serialVersionUID = 0L;

}
