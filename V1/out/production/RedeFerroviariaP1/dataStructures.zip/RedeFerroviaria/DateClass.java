package RedeFerroviaria;

public class DateClass implements Date{
    private int minutes;
    private int hour;

    static final long serialVersionUID = 0L;

    public DateClass(String time){
        String[] t = time.split(":");
        hour = Integer.parseInt(t[0]);
        minutes = Integer.parseInt(t[1]);
    }

    public DateClass(int hour, int minutes){
        this.hour = hour;
        this.minutes = minutes;
    }

    @Override
    public int getHour() {
        return hour;
    }

    @Override
    public int getMinutes() {
        return minutes;
    }
}
