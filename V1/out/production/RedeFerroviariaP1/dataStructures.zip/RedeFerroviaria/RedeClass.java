package RedeFerroviaria;

import dataStructures.*;

public class RedeClass implements Rede{
    private static int DEFAULT_CAPACITY = 30;
    private static int GROW_FACTOR = 2;
    private Dictionary<String, Line> lines;
    private String[] orderedLines;
    private int size;


    // tirar dicionario de ordenado
    // tirar binary search dentro da line

    static final long serialVersionUID = 0L;

    public RedeClass(){
        lines = new DictionaryClass<>();
        orderedLines = new String[DEFAULT_CAPACITY];
        size = 0;
    }

    private boolean isFull(){
       return orderedLines.length == size;
    }

    private void grow(){
        String[] aux = new String[orderedLines.length * GROW_FACTOR];
        for (int i = 0; i < orderedLines.length; i++){
            aux[i] = orderedLines[i];
        }
        orderedLines = aux;
    }

    @Override
    public boolean hasLine(String line) {
        return linesBinarySearch(line) != -1;
    }

    private int linesBinarySearch(String line){
        int left = 0;
        int right = size - 1;
        if (size == 0){
            return -1;
        }

        // Loop to implement Binary Search
        while (left <= right) {

            // Calculatiing mid
            int mid = (left + right) / 2;

            int result = line.compareToIgnoreCase(orderedLines[mid]);

            // Check if x is present at mid
            if (result == 0)
                return mid;

            // If x greater, ignore left half
            if (result > 0)
                left = mid + 1;

                // If x is smaller, ignore right half
            else
                right = mid - 1;
        }
        return -1;
    }


    @Override
    public boolean hasSchedule(String line, String startingStation, String hour) {
        Line l = lines.find(line);
        return l.hasSchedule(startingStation, hour);
    }

    //
    @Override
    public boolean isStartingStation(String line, String startingStation) {
        Line l = lines.find(line);
        return l.isTerminalStation(startingStation);
    }

    @Override
    public boolean isPossible(String line, String endingStation) {
        Line l = lines.find(line);
        return l.hasStation(endingStation);
    }

    @Override
    public boolean orderCorrect(String line, List<Entry<String, String>> stations) {
        Line l = lines.find(line);
        return l.orderCorrect(stations);
    }

    @Override
    public void insertLine(String line) {
        Line l = new LineClass(line);
        int idx = findNewLinePosition(line);
        lines.insertAtPos(idx, line, l);
        insertOrdered(idx, line);
    }

    private void insertOrdered(int idx, String line){
        if (isFull()){
            grow();
        }
        if (idx == size){
            orderedLines[size++] = line;
        } else {
            for(int i = size - 1; i >= idx; i--){
                orderedLines[i+1] = orderedLines[i];
            }
            orderedLines[idx] = line;
            size++;
        }
    }

    private int findNewLinePosition(String line){
        int idx = -1;
        int i = 0;
        Iterator<Entry<String, Line>> ite = lines.iterator();
        while(ite.hasNext() && idx == -1){
            Entry<String, Line> entry = ite.next();
            if (line.compareTo(entry.getKey()) < 0){
                idx = i;
            }
            i++;
        }
        if (idx == -1){
            return lines.size();
        }
        return idx;
    }


    @Override
    public void addStationToLine(String line, List<String> station) {
        Iterator<String> ite = station.iterator();
        Line l = lines.find(line);
        l.setStationNumber(station.size());
        if (l != null){
            while (ite.hasNext()){
                String s = ite.next();
                l.addStation(s);
            }
        }
        l.sortStations();
    }

    @Override
    public void removeLine(String line) {
        int idx = linesBinarySearch(line);
        String l = orderedLines[idx];
        removeArray(idx);
        size--;
        lines.remove(l);
    }

    private void removeArray(int idx) {
        for (int i = idx; i < orderedLines.length - 2; i++){
            orderedLines[i] = orderedLines[i+1];
        }
    }

    @Override
    public boolean removeSchedule(String line, String startingStation, String hour) {
        Line l = lines.find(line);
        return l.removeSchedule(startingStation, hour);
    }

    @Override
    public void insertSchedule(String line, int trainNr, List<Entry<String, String>> stations) {
        Line l = lines.find(line);
        l.addSchedule(trainNr, stations);
    }

    /**
    @Override
    public boolean hasTrainsStarting(String line, String startingStation) {
        Line l = lines.find(line);
        return l.hasTrainsStarting(startingStation);
    }
    */

    @Override
    public Iterator<String> iteratorByLine(String line) {
        Line l = lines.find(line);
        if (l != null){
            return l.stationsIterator();
        }
        return null;
    }

    @Override
    public Iterator<Train> scheduleByLineIterator(String line, String startingStation) {
        Line l = lines.find(line);
        if (l != null){
            Iterator<Train> ite = l.trainsPerStationsIterator(startingStation);
            return l.trainsPerStationsIterator(startingStation);
        }
        return null;
    }

    @Override
    public Train bestTimeTable(String line, String startingStation, String endingStation, String hour) {
        Line l = lines.find(line);
        return l.bestTimeTable(startingStation, endingStation, hour);
    }
}
