package RedeFerroviaria;

import dataStructures.Entry;
import dataStructures.Iterator;
import dataStructures.List;

public class TrainClass implements Train {
    private int nr;
    private Date departureTime;
    private String[] stops;
    private int size;
    private List<Entry<String, Date>> schedule;

    static final long serialVersionUID = 0L;

    public TrainClass(int nr, List<Entry<String, Date>> schedule){
        this.nr = nr;
        this.departureTime = schedule.getFirst().getValue();
        this.schedule = schedule;
        this.stops = new String[this.schedule.size()];
        size = 0;
        sortStations();
    }

    // tornar static
    private void sortStations(){
        addStations();
        for (int i = 1; i < size; ++i) {
            String key = stops[i];
            int j = i - 1;

            while (j >= 0 && stops[j].compareTo(key) > 0) {
                stops[j + 1] = stops[j];
                j = j - 1;
            }
            stops[j + 1] = key;
        }
    }

    private void addStations(){
        Iterator<Entry<String, Date>> ite = scheduleIterator();
        while (ite.hasNext()){
            Entry<String, Date> entry = ite.next();
            stops[size++] = entry.getKey();
        }
    }

    private int stationsBinarySearch(String station){
        int left = 0;
        int right = size - 1;

        // Loop to implement Binary Search
        while (left <= right) {

            // Calculatiing mid
            int mid = (left + right) / 2;

            int result = station.compareTo(stops[mid]);

            // Check if x is present at mid
            if (result == 0)
                return mid;

            // If x greater, ignore left half
            if (result > 0)
                left = mid + 1;

                // If x is smaller, ignore right half
            else
                right = mid - 1;
        }
        return -1;
    }


    @Override
    public int compareTo(Train o) {
        return Integer.compare(nr, o.getNr());
    }

    @Override
    public int getNr() {
        return nr;
    }

    @Override
    public boolean hasSchedule(String startingStation, Date time) {
        boolean isStartingStation = schedule.getFirst().getKey().equalsIgnoreCase(startingStation) || schedule.getLast().getKey().equalsIgnoreCase(startingStation);
        if (!isStartingStation){
            return false;
        } else {
            return stationHasTime(time);
        }
    }

    @Override
    public Iterator<Entry<String, Date>> scheduleIterator() {
        return schedule.iterator();
    }

    @Override
    public Date getDepartureTime() {
        return departureTime;
    }

    @Override
    public boolean hasStation(String startingStation) {
        return stationsBinarySearch(startingStation) != -1;
    }

    @Override
    public int leeway(Date arrivalTime, String endingStation) {
        int diff = Integer.MAX_VALUE;
        boolean found = false;
        Iterator<Entry<String, Date>> ite = schedule.iterator();
        while (ite.hasNext() && !found){
            Entry<String, Date> entry = ite.next();
            if (entry.getKey().equalsIgnoreCase(endingStation)){
                diff = Date.calculateDiff(arrivalTime, entry.getValue());
                found = true;
            }
        }
        if (diff < 0){
            return Integer.MAX_VALUE;
        }
        return diff;
    }

    private boolean stationHasTime(Date time){
       return schedule.getFirst().getValue().getHour() == time.getHour() || schedule.getLast().getValue().getMinutes() == time.getMinutes();
    }
}
