/**
 * Interface Date
 * @Authors Francisco Correia 67264 & Sérgio Garrido 67202
 */



package RedeFerroviaria;

import dataStructures.Entry;
import dataStructures.Iterator;
import dataStructures.List;
import java.io.Serializable;


/**
 * Interface Rede responsible to prototype methods to handle a Rede Object, extending Serializable
 */
public interface Rede extends Serializable {
    /**
     * Checks if a given line is on the system
     * @param line - The name of the line
     * @return true if the line is on the system. Otherwise, false
     */
    boolean hasLine(String line);

    /**
     * Checks if a given line has a train that stops at a given station at a given hour
     * @param line - The name of the line
     * @param startingStation - The name of the station
     * @param hour - The hour of the schedule
     * @return true if a given line has a train that stops at a given station at a given hour. Otherwise, false
     */
    boolean hasSchedule(String line, String startingStation, String hour);

    /**
     * Checks if a given station is a terminal station of a given line
     * @param line - The name of the line
     * @param startingStation - The name of the station
     * @return true if a given station is a terminal station of a given line. Otherwise, false
     */
    boolean isStartingStation(String line, String startingStation);

    /**
     * Checks if a train in a given line stops at a given station
     * @param line - The name of the line
     * @param endingStation - The name of the station
     * @return true if a train in a given line stops at a given station. Otherwise, false
     */
    boolean isPossible(String line, String endingStation);

    /**
     * Checks if the order of stations of a given list corresponds to the order of the stations of a given line
     * @param line - The name of the line
     * @param stations - The list of stations
     * @return true if the order of stations of a given list corresponds to the order of the stations of a given line. Otherwise, false
     */
    boolean orderCorrect(String line, List<Entry<String, String>> stations);

    /**
     * Returns an iterator of Objects of type String corresponding to the stations of a given line
     * @param line - The name of the line
     * @return an iterator of Objects of type String corresponding to the stations of a given line. Otherwise, false
     */
    Iterator<String> iteratorByLine(String line);

    /**
     * Returns an iterator of Objects of type Train corresponding to the trains of a given line that start a given station
     * @param line - The name of the line
     * @param startingStation - The name of the station
     * @return an iterator of Objects of type String corresponding to the stations of a given line
     */
    Iterator<Train> scheduleByLineIterator(String line, String startingStation);

    /**
     * Finds the train that best suits a given arrival time in a station of a given line
     * @param line - The name of the line
     * @param startingStation - The name of the departure station
     * @param endingStation - The name of the arrival station
     * @param hour - The expected hour of arrival
     * @return an Object of type Train corresponding to the train that best suits a given arrival time in a station of a given line
     */
    Train bestTimeTable(String line, String startingStation, String endingStation, String hour);

    // criar classe e interface que extende esta. e onde apenas estao estes metodos (classe editavel)
    void insertLine(String line);
    void addStationToLine(String line, List<String> aux);
    void removeLine(String line);
    boolean removeSchedule(String line, String startingStation, String hour);
    void insertSchedule(String line, int trainNr, List<Entry<String, String>> stations);

/**
    boolean hasTrainsStarting(String line, String startingStation);
 */
}
