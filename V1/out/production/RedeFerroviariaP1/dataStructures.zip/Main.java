import java.io.*;
import java.util.Scanner;
import RedeFerroviaria.*;
import dataStructures.*;


public class Main {
    private static final String FILE = "saveState.txt";
    private static final String INSERT_LINE = "IL";
    private static final String REMOVE_LINE = "RL";
    private static final String CHECK_LINE = "CL";
    private static final String INSERT_SCHEDULE = "IH";
    private static final String REMOVE_SCHEDULE = "RH";
    private static final String LIST_LINE_SCHEDULE = "CH";
    private static final String BEST_TIME_TABLE = "MH";
    private static final String TERMINATE_APPLICATION = "TA";



    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        redeFerroviaria(in);
    }

    private static void redeFerroviaria(Scanner in){
        Rede rede = load();
        String command;
        do {
            command = in.next().toUpperCase();
            switch (command) {
                case INSERT_LINE -> insertLine(in, rede);
                case REMOVE_LINE -> removeLine(in, rede);
                case CHECK_LINE -> checkLine(in, rede);
                case INSERT_SCHEDULE -> insertSchedule(in, rede);
                case REMOVE_SCHEDULE -> removeSchedule(in, rede);
                case LIST_LINE_SCHEDULE -> listLineSchedule(in, rede);
                case BEST_TIME_TABLE -> bestTimeTable(in, rede);
                case TERMINATE_APPLICATION -> terminateApplication(rede);
            }
        } while (!command.equals(TERMINATE_APPLICATION));
    }

    private static void insertLine(Scanner in, Rede rede){
        String line = in.nextLine().trim();
        List<String> aux = new DoubleList<>();

        boolean end = false;
        while (!end){
            String station = in.nextLine().trim();
            if (station.isEmpty()){
                end = true;
            } else {
                aux.addLast(station);
            }
        }

        if (rede.hasLine(line)){
            System.out.println("Linha existente.");
        } else {
            rede.insertLine(line);
            rede.addStationToLine(line, aux);
            System.out.println("Inserção de linha com sucesso.");
        }
    }

    private static void removeLine(Scanner in, Rede rede){
        String line = in.nextLine().trim();
        if (!rede.hasLine(line)){
            System.out.println("Linha inexistente.");
        } else {
            rede.removeLine(line);
            System.out.println("Remoção de linha com sucesso.");
        }
    }


    private static void checkLine(Scanner in, Rede rede){
        String line = in.nextLine().trim();
        if (!rede.hasLine(line)){
            System.out.println("Linha inexistente.");
        } else {
            Iterator<String> ite = rede.iteratorByLine(line);
            while(ite.hasNext()){
                String station = ite.next();
                System.out.println(station);
            }
        }
    }

    private static void insertSchedule(Scanner in, Rede rede) {
        String line = in.nextLine().trim();

        if (!rede.hasLine(line)){
            System.out.println("Linha inexistente.");
        } else {
            int trainNr = in.nextInt();
            in.nextLine();
            boolean end = false;
            List<Entry<String, String>> stations = new DoubleList<>();
            while(!end){
                String stationAndHour = in.nextLine().trim();
                if (stationAndHour.isEmpty()){
                    end = true;
                } else {
                    int index = stationAndHour.indexOf(":");
                    String station = stationAndHour.substring(0, index - 3);
                    String hour = stationAndHour.substring(index - 2);
                    Entry<String, String> entry = new EntryClass<>(station, hour);
                    stations.addLast(entry);
                }
            }
            if (!rede.isStartingStation(line, stations.getFirst().getKey()) || !rede.orderCorrect(line, stations)){
                System.out.println("Horário inválido.");
            } else {
                rede.insertSchedule(line, trainNr, stations);
                System.out.println("Criação de horário com sucesso.");
            }
        }
    }

    private static void removeSchedule(Scanner in, Rede rede){
        String line = in.nextLine().trim();

        if (!rede.hasLine(line)){
            System.out.println("Linha inexistente.");
        } else {
            String stationAndHour = in.nextLine().trim();
            int index = stationAndHour.indexOf(":");
            String station = stationAndHour.substring(0, index - 3);
            String hour = stationAndHour.substring(index - 2);

             if (!rede.hasSchedule(line, station, hour)){
                System.out.println("Horário inexistente.");
            } else {
                rede.removeSchedule(line, station, hour);
                System.out.println("Remoção de horário com sucesso.");
            }
        }
    }


    private static void listLineSchedule(Scanner in, Rede rede) {
        String line = in.nextLine().trim();
        String startingStation = in.nextLine().trim();

        if (!rede.hasLine(line)) {
            System.out.println("Linha inexistente.");
        } else if (!rede.isStartingStation(line, startingStation)) {
            System.out.println("Estação de partida inexistente.");
        } else {
            Iterator<Train> ite = rede.scheduleByLineIterator(line, startingStation);
            if (ite != null) {
                while (ite.hasNext()) {
                    Train t = ite.next();
                    System.out.printf("%d\n", t.getNr());
                    Iterator<Entry<String, Date>> scheduleIte = t.scheduleIterator();
                    while (scheduleIte.hasNext()) {
                        Entry<String, Date> entry = scheduleIte.next();
                        System.out.printf("%s %02d:%02d\n", entry.getKey(), entry.getValue().getHour(), entry.getValue().getMinutes());
                    }
                }
            }
        }
    }


    private static void bestTimeTable(Scanner in, Rede rede){
        String line = in.nextLine().trim();
        String startingStation = in.nextLine().trim();
        String endingStation = in.nextLine().trim();
        String hour = in.nextLine().trim();

        if (!rede.hasLine(line)){
            System.out.println("Linha inexistente.");
        } else if (!rede.isPossible(line, startingStation)){
            System.out.println("Estação de partida inexistente.");
        } else if (!rede.isPossible(line, endingStation)){
            System.out.println("Percurso impossível.");
        } else {
            Train t = rede.bestTimeTable(line, startingStation, endingStation, hour);
            if (t != null){
                System.out.println(t.getNr());
                Iterator<Entry<String, Date>> ite = t.scheduleIterator();
                while (ite.hasNext()){
                    Entry<String, Date> entry = ite.next();
                    System.out.printf("%s %02d:%02d\n", entry.getKey(), entry.getValue().getHour(), entry.getValue().getMinutes());
                }
            }
        }
    }

    private static void terminateApplication(Rede rede){
        save(rede);
        System.out.println("Aplicação terminada.");
    }

    private static void save(Rede rede){
        try{
            ObjectOutputStream file = new ObjectOutputStream(new FileOutputStream(FILE));
            file.writeObject(rede);
            file.flush();
            file.close();
        } catch (IOException e){
            System.out.println("Erro a salvar.");
        }
    }

    private static Rede load(){
        try{
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE));
            Rede rede = (Rede) ois.readObject();
            ois.close();
            return rede;
        } catch (FileNotFoundException e) {
            return new RedeClass();
        } catch (IOException e) {
            return new RedeClass();
        } catch (ClassNotFoundException e) {
            return new RedeClass();
        }
    }
}