package dataStructures;

public class DictionaryClass<K extends Comparable<K>,V> implements Dictionary<K,V> {
    private int currentSize;
    private List<Entry<K,V>> list;

    static final long serialVersionUID = 0L;

    public DictionaryClass(){
        currentSize = 0;
        list = new DoubleList<>();
    }

    @Override
    public boolean isEmpty() {
        return currentSize == 0;
    }

    @Override
    public int size() {
        return currentSize;
    }

    @SuppressWarnings("unchecked")
    @Override
    public V find(K key) {
        Entry<K,V> entry = createDummyEntry(key);
        int idx = list.find(entry);
        if (idx != -1){
            return list.get(idx).getValue();
        } else {
            return null;
        }
    }

    @Override
    public V insert(K key, V value) {
        Entry<K,V> entry = createEntry(key, value);
        list.addLast(entry);
        currentSize++;
        return value;
    }

    @Override
    public V insertAtPos(int position, K key, V value) {
        Entry<K,V> entry = createEntry(key, value);
        list.add(position, entry);
        currentSize++;
        return value;
    }


    @Override
    public V remove(K key) {
        Entry<K,V> entry = createDummyEntry(key);
        int idx = list.find(entry);
        V value = find(key);
        list.remove(idx);
        currentSize--;
        return value;
    }

    private Entry<K,V> createDummyEntry(K key){
        return new EntryClass<>(key, null);
    }

    private Entry<K,V> createEntry(K key, V value){
        return new EntryClass<>(key, value);
    }

    @Override
    public Iterator<Entry<K, V>> iterator() {
        return list.iterator();
    }
}
